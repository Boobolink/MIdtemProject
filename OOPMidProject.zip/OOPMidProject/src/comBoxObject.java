public class comBoxObject {

        private String value;
        private String text;

        public comBoxObject(String value, String text) {
            this.value = value;
            this.text = text;
        }
        @Override
        public String toString() {
            return text;
        }
}
