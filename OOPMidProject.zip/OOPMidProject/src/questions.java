import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Timer;

public class questions {
    private JPanel panel1;
    private JRadioButton aRadioButton;
    private JRadioButton bRadioButton;
    private JRadioButton cRadioButton;
    private JRadioButton dRadioButton;
    private JButton button1;
    private JLabel queastLabel;
    public JLabel timerOut;
    private JButton backButton;
    private static JFrame frame;
    private static String[][] quests;
    private static String[] answers;
    private int c = 0;
    private boolean[] rightAnswers;
    private static int numberOfQ;
    private int time;
    private String login_;


    private String whatSelected(){
        if (aRadioButton.isSelected()) return "a";
        else if (bRadioButton.isSelected()) return "b";
        else if (cRadioButton.isSelected()) return "c";
        else if (dRadioButton.isSelected()) return "d";
        else return "-";
    }

    public questions(int numQuestions, int time, String login) {
        this.login_ = login;
        this.numberOfQ = numQuestions;
        this.time = time;
        Question questst = new Question(numberOfQ);
        quests = questst.getQuestion();
        answers = new String[numberOfQ];
        rightAnswers = new boolean[numberOfQ];
        setQuestion(c);
        backButton.setVisible(false);
        TimerTime t = new TimerTime(questions.this, time);
        button1.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                backButton.setVisible(true);
                if (c < numberOfQ - 1) {
                    answers[c] = whatSelected();
                    c++;
                    setQuestion(c);
                    if (c == (numberOfQ - 1))
                        button1.setText("Submit");
                } else {
                    answers[c] = whatSelected();
                    checkIt(quests, answers);
                    Timer timer = new Timer();
                    timer.cancel();
                    new Analiz(questions.this, quests, answers, checkAll(), login_);
                    frame.dispose();
                }
            }
        });
        backButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (c <= 1){
                    backButton.setVisible(false);
                }
                if (c > 0){
                    setQuestion(--c);
                    if (c < numberOfQ - 1) button1.setText("Next");
                }
            }
        });
    }
    public void autoSubmit(){
        for(int i = c; i < numberOfQ; i++){
            answers[i] = "-1";
        }
        checkIt(quests, answers);
        new Analiz(questions.this, quests, answers, checkAll(), login_);
    }
    protected int checkAll(){
        int points = 0;
        for(int counter = 0; counter < numberOfQ; counter++){
            if (rightAnswers[counter]) points++;
        }
        return points;
    }
    protected void checkIt(String[][] question, String[] answers){
        for(int counter = 0; counter < question.length; counter++){
            if (question[counter][5].equals(answers[counter])) rightAnswers[counter] = true;
            else rightAnswers[counter] = false;
        }
    }
    private void setQuestion(int Number){
        queastLabel.setText((Number+1)+") " +quests[Number][0]);
        aRadioButton.setText(quests[Number][1]);
        bRadioButton.setText(quests[Number][2]);
        cRadioButton.setText(quests[Number][3]);
        dRadioButton.setText(quests[Number][4]);
    }

    public void showQuestionsPanel(boolean isVisible) {
        frame = new JFrame("questions");
        frame.setContentPane(this.panel1);
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        frame.pack();
        frame.setVisible(isVisible);
        frame.setSize(800, 400);
        frame.setResizable(false);
    }

}