import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class menu {
    private JButton button1;
    private JButton button2;
    private JPanel panel;
    private JLabel name;
    private JLabel surname;
    private JLabel group;
    private JLabel lep;
    private JButton exitButton;
    private JFrame frame;
    private String login;

    public void showQuestionsPanel(boolean isVisible) {
        frame = new JFrame("questions");
        frame.setContentPane(this.panel);
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        frame.pack();
        frame.setVisible(isVisible);
        frame.setSize(800, 450);
        frame.setResizable(false);
        name.setText("Name: "+Form.getUser(login)[2]);
        surname.setText("Surname: "+Form.getUser(login)[3]);
        group.setText("Group: " +Form.getUser(login)[4]);
        lep.setText("Last exam point is: " + Form.getLastPoints(login));
    }

    public menu(String login) {
        this.login = login;
        button1.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                newQuestions ques = new newQuestions();
                ques.showQuestionsPanel(true);
            }
        });
        button2.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                questions ques = new questions(20, 30, login);
                ques.showQuestionsPanel(true);

            }
        });

        exitButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                frame.dispose();
            }
        });
    }
}
