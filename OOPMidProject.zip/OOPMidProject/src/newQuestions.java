import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class newQuestions {
    private JTextField q;
    private JTextField d;
    private JTextField a;
    private JTextField c;
    private JTextField b;
    private JComboBox ans;
    private JButton button1;
    private JPanel panel;
    private JFrame frame;

    public newQuestions() {
        button1.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (q.getText().isEmpty()) JOptionPane.showMessageDialog(null, "Please fill the question field", "Error", JOptionPane.ERROR_MESSAGE);
                else if (a.getText().isEmpty())JOptionPane.showMessageDialog(null, "Please fill the a variant field", "Error", JOptionPane.ERROR_MESSAGE);
                else if (b.getText().isEmpty())JOptionPane.showMessageDialog(null, "Please fill the b variant field", "Error", JOptionPane.ERROR_MESSAGE);
                else if (c.getText().isEmpty())JOptionPane.showMessageDialog(null, "Please fill the c variant field", "Error", JOptionPane.ERROR_MESSAGE);
                else if (d.getText().isEmpty())JOptionPane.showMessageDialog(null, "Please fill the d variant field", "Error", JOptionPane.ERROR_MESSAGE);
                else {
                    if(Form.saveQuestion(q.getText(), a.getText(), b.getText(),c.getText(),d.getText(),ans.getSelectedItem().toString())) {
                        JOptionPane.showMessageDialog(null, "Thank you! Your question saved!", "Success", JOptionPane.INFORMATION_MESSAGE);
                        frame.dispose();
                    }
                    else {
                        JOptionPane.showMessageDialog(null, "Your question wasn't saved", "Error", JOptionPane.ERROR_MESSAGE);
                    }
                }
            }
        });

    }

    public void showQuestionsPanel(boolean isVisible) {
        frame = new JFrame("Adding new Questions");
        frame.setContentPane(this.panel);
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        frame.pack();
        frame.setVisible(isVisible);
        frame.setResizable(false);
    }
}
