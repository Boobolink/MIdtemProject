import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Analiz extends JFrame {
    private JPanel panel1;
    private JLabel field;
    private JLabel points;
    private JScrollPane scroll;
    private JButton OKButton;
    private questions display;
    private static JFrame frame;
    private String common;
    public String textStart,textEnd;

    public Analiz(final questions main, String[][] questions,
                  String[] answers, int point, String login) {
        this.display = main;
        points.setText("You have answered " + point + " from " +
                questions.length + "  Total  "+ 5 * point + " points from 100!");
        textStart = "<html><body>";
        textEnd = "</body></html>";
        Form.savePoint(login, 5 * point);
        common = "";
        for (int i = 0; i < questions.length; i++){
            common +=(i + 1) + ")" + questions[i][0] + "<br>";
            if (getRightAnswer(answers[i]) != -1) {
                if (questions[i][5].equals(answers[i])) common += "You chose: " +
                        questions[i][getRightAnswer(answers[i])] + ", and it is right.<br>";
                else  common += "You chose incorrect answer (" + questions[i][getRightAnswer(answers[i])] +
                        ")<br>The right answer is: "+ questions[i][5] + ") " +
                        questions[i][getRightAnswer(questions[i][5])] +" <br>";
            } else {
                common += "You haven't chose any answer.<br> The right answer was: " +
                        questions[i][5] + ") " + questions[i][getRightAnswer(questions[i][5])] +" <br>";
            }
            common += "<hr><br>";
        }
        field.setText(textStart + common + textEnd);
        display();
        OKButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                frame.dispose();
            }
        });
    }
    public int getRightAnswer(String a){
        if (a.equals("a"))
            return 1;
        else if (a.equals("b"))
            return 2;
        else if (a.equals("c"))
            return 3;
        else if (a.equals("d"))
            return 4;
        else
            return -1;
    }

    public void display(){
        frame = new JFrame("Test Result");
        frame.setContentPane(this.panel1);
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        frame.pack();
        frame.setLayout(null);
        frame.setVisible(true);
        frame.setResizable(false);
    }

}
