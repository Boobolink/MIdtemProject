import java.io.*;
public class Form {
    public static boolean registrate(String login, String password, String name, String surname, String group){
        try
        {
            File file = new File("users.db");
            BufferedWriter writer = new BufferedWriter(new FileWriter(file, true));
            writer.write(login+ "%" + password + "%" + name + "%" + surname + "%" + group);
            writer.newLine();
            writer.close();
            return true;
        }
        catch(FileNotFoundException e)
        {
            System.out.println("Users file  not found");
            System.exit( 1 );
        }
        catch(IOException e)
        {
            System.out.println("Error in Registration");
            System.exit( 1 );
        }
        return false;
    }

    public static boolean savePoint(String login, int points){
        try
        {
            File file = new File("points.db");
            BufferedWriter writer = new BufferedWriter(new FileWriter(file, true));
            writer.write(login+ "%" + points );
            writer.newLine();
            writer.close();
            return true;
        }
        catch(FileNotFoundException e)
        {
            System.out.println("Points file  not found");
            System.exit( 1 );
        }
        catch(IOException e)
        {
            System.out.println("Error in savePoints");
            System.exit( 1 );
        }
        return false;
    }
    public static boolean saveQuestion(String question, String a, String b, String c, String d, String ans){
        try
        {
            File file = new File("questions.db");
            BufferedWriter writer = new BufferedWriter(new FileWriter(file, true));
            writer.write(question + "%" + a + "%" + b + "%" + c + "%" + d + "%" + ans  );
            writer.newLine();
            writer.close();
            return true;
        }
        catch(FileNotFoundException e)
        {
            System.out.println("Questions file not found");
            System.exit( 1 );
        }
        catch(IOException e)
        {
            System.out.println("Error in save Questions");
            System.exit( 1 );
        }
        return false;
    }

    public static String[] getUser(String login){
        BufferedReader reader = null;
        String[] user = {};
        try {
            File file = new File("users.db");
            reader = new BufferedReader(new FileReader(file));
            String line;
            user = new String[5];
            reader = new BufferedReader(new FileReader(file));
            while ((line = reader.readLine()) != null) {
                String[] info = line.split("%");
                if (info[0].equalsIgnoreCase(login)) user = info;
            }
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
                reader.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        return user;
    }
    public static int numOfQuestOfDb(){
        BufferedReader reader = null;
        int c = 0;
        try {
            File file = new File("questions.db");
            reader = new BufferedReader(new FileReader(file));
            while (reader.readLine()!= null) {
                c++;
            }
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
                reader.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        return c;
    }
    public static String getLastPoints(String login){
        BufferedReader reader = null;
        String points = "";
        try {
            File file = new File("points.db");
            reader = new BufferedReader(new FileReader(file));
            String line;
            while ((line = reader.readLine()) != null) {
                String[] info = line.split("%");
                if (info[0].equalsIgnoreCase(login)) points = info[1];
                else points="You have not any points yet";
            }
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
                reader.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        return points;
    }
    public static boolean checkUser(String login, String password){
        BufferedReader reader = null;
        try {
            File file = new File("users.db");
            reader = new BufferedReader(new FileReader(file));
            String line;

            reader = new BufferedReader(new FileReader(file));
            while ((line = reader.readLine()) != null) {
                String[] info = line.split("%");
                if (info[0].equalsIgnoreCase(login) && info[1].equalsIgnoreCase(password)) return true;
            }
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
                reader.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        return false;
    }
    public static boolean checkLogin(String login){
        BufferedReader reader = null;
        try {
            File file = new File("users.db");
            reader = new BufferedReader(new FileReader(file));
            String line;
            reader = new BufferedReader(new FileReader(file));
            while ((line = reader.readLine()) != null) {
                String[] info = line.split("%");
                if (info[0].equalsIgnoreCase(login)) return true;
            }
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
                reader.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        return false;
    }
    public static String[][] getQuestions(){
        String[][] questions = {};
        BufferedReader reader = null;
        try {
            File file = new File("questions.db");
            String line;
            reader = new BufferedReader(new FileReader(file));
            int c = 0;
            while (reader.readLine() != null) {
                c++;
            }
            reader = new BufferedReader(new FileReader(file));
            questions = new String[c][6];
            c = 0;
            while ((line = reader.readLine()) != null) {
                String[] info = line.split("%");
                questions[c] = info;
                c++;
            }
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
                reader.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        return questions;
    }
}
