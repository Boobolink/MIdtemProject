public class Examination {
    public static void main(String[] args) {
        registration.showRegistrationPanel(true);

    }
}
